/// <reference path="globals/express-serve-static-core/index.d.ts" />
/// <reference path="globals/express/index.d.ts" />
/// <reference path="globals/mime/index.d.ts" />
/// <reference path="globals/node/index.d.ts" />
/// <reference path="globals/serve-static/index.d.ts" />
/// <reference path="manual/body-parser/body-parser.d.ts" />
/// <reference path="manual/method-override/method-override.d.ts" />
/// <reference path="manual/mongoose/mongoose.d.ts" />
